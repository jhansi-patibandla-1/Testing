# Employee-Management-System
""" A small scale employee management system developed from scrach for practice purpose """
